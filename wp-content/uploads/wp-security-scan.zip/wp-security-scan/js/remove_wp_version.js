jQuery(document).ready(function($) {
	$("#wp-version-message, #footer-upgrade").remove();
});
