<?php

function mrt_wpss_menu_head($title){

	echo '
		<div class="wrap">
      		<h2 class="wpss_icon">' . $title . '</h2>';  
	
}

?>