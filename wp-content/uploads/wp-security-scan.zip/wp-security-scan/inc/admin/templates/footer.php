<?php

function mrt_wpss_menu_footer(){
	echo '
<div style="clear:both;"></div>
    <br />
    <em>For comments, suggestions, queries and bug reports please visit
    the <a href="http://www.websitedefender.com/forums/" target="_blank"
    title="WebsiteDefender Forums">WebsiteDefender Forums</a></em>.
    <br/>
    Plugin by <a href="http://websitedefender.com/" target="_blank"
    title="WebsiteDefender">WebsiteDefender</a>
</div>
	';
}

?>