=== jQuery Image Lazy Load WP ===
Contributors: ayn, jtai
Tags: images, jquery, javascript, optimization
Requires at least: 2.8
Tested up to: 3.5.1
Stable tag: 0.20

add jquery lazy loading to images

== Description ==

add lazy loading to WP, more info at http://plugins.jquery.com/project/lazyload

== Installation ==

unzip archive to wp-content/plugins directory, and activate it in Plugins page in wp-admin

or you can cd into your wordpress_root/wp-contents/plugins and do:

git clone git://github.com/ayn/wp-jquery-lazy-load.git
